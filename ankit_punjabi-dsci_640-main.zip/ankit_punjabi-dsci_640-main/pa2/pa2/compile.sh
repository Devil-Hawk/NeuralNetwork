javac -Xlint:unchecked ./data/*.java ./util/*.java ./network/*.java *.java
