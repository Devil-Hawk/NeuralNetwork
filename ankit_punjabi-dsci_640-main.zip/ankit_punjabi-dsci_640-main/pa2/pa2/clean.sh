rm *.class
rm */*.class
