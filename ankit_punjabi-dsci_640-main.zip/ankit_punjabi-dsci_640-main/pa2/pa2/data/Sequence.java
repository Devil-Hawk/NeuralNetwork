package data;

public interface Sequence {

    //returns the maximum length of a sequence
    int getLength();

}
