package network;

/**
 * An enumeration which we can use to specify what types nodes
 * can be.
 */
public enum NodeType { 
    INPUT, HIDDEN, OUTPUT;
}

