package network;

public enum LossFunction {
    NONE, L1_NORM, L2_NORM, SVM, SOFTMAX;
}
